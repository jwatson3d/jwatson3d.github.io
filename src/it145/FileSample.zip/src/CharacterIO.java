import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import static java.lang.System.err;
import static java.lang.System.out;

/**
 * File Input/Output using character i/o to process a text file a character at a
 * time.
 *
 * IT-145 Foundations of Application Development
 *
 * College of Online and Continuing Education Southern New Hampshire University
 *
 * @author John Watson <john.watson@snhu.edu>
 */
public class CharacterIO {

    // represents the actual file on disk
    File file = null;

    // convenience class for reading streams of characters
    FileReader fileReader = null;

    // the filename
    String filename;

    // define array of strings to hold individual fields
    String[] fields;

    // define a format string to ensure consistent output
    // @see https://docs.oracle.com/javase/8/docs/api/java/util/Formatter.html
    String format = "%-3s %-10s %-10s %-40s";

    /**
     * Prevent default constructor being called
     */
    private CharacterIO() {

    }

    /**
     * 
     * @param filename 
     */
    public CharacterIO(String filename) {
        this.filename = filename;
    }

    /**
     * Reads the selected file and prints the contents
     */
    public void readFile() {

        // if able to open the file
        if (prepareFile()) {

            try {
                int input;
                char ch;
                
                int fieldNum = 0;

                // initialize String array elements
                fields = new String[]{"","","","","",""};

                // keep reading characters until end-of-file
                // @see http://docs.oracle.com/javase/8/docs/api/java/io/InputStreamReader.html#read--
                while ((input = fileReader.read()) != -1) {
                    // cast integer value into a character
                    ch = (char) input;

                    // now figure out what to do with the character just read
                    switch (ch) {

                        // newline character - reached end of a line
                        case '\n':
                            // print out the fields previously read
                            out.println(String.format(format, fields[0], fields[1], fields[2], fields[3]));
                            // initialize String array elements
                            fields = new String[]{"","","","","",""};
                            // reset field number back to zero (first element)
                            fieldNum = 0;
                            break;

                            // return character - ignore (Windows-style encoding)
                        case '\r':
                            break;
                            
                        // comma reached so increment field number
                        case ',':
                            fieldNum++;
                            break;

                        // append character to current field
                        default:
                            fields[fieldNum] += ch;
                    }
                }

                // always close the file
                fileReader.close();

            } catch (IOException ex) {
                err.format("IOException: %s%n", ex);
            }
        }
    }

    /**
     * Prepares a File instance using the supplied filename
     *
     * @return 'true' if the file is prepared for use
     */
    private boolean prepareFile() {

        // Determine the correct path location for the file
        // see: http://stackoverflow.com/a/10830715
        URL path = CharacterIO.class.getResource(filename);
        if (path == null) {
            System.err.format("File not found!! Unable to continue.");
            return false;
        }

        // try to create a File instance using the calculated path
        try {
            file = new File(path.toURI());
        } catch (URISyntaxException ex) {
            System.err.format("IOException: %s%n", ex);
            return false;
        }

        // try to construct a FileReader instance 
        try {
            // open the file and position to the start
            fileReader = new FileReader(file);
        } catch (FileNotFoundException ex) {
            System.err.format("FileNotFoundException: %s%n", ex);
            return false;
        }

        return true;
    }
}
