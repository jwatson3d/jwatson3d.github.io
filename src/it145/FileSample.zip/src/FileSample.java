import static java.lang.System.out;
import java.util.Scanner;

/*
 * File Input/Output example
 *
 * IT-145 Foundations of Application Development
 *
 * College of Online and Continuing Education
 * Southern New Hampshire University
 *
 * @author John Watson <john.watson@snhu.edu>
 *
 * Compile command:
 *   > javac FileSample.java
 *
 * Run command:
 *   > java -cp . FileSample
 *
 */
public class FileSample {
    
    // name of the sample file
    static String filename = "sample.csv";

    /**
     * The one and only main() method is our starting point
     * 
     * @param args 
     */
    public static void main(String[] args) {
        boolean exit = false;
        
        // main loop runs until exit requested
        while (!exit) {
            int option = showMenu();
            switch (option) {
                case 1:
                    CharacterInput characterInput = new CharacterInput(filename);
                    characterInput.readFile();
                    break;
                case 2:
                    BufferedInput bufferedInput = new BufferedInput(filename);
                    bufferedInput.readFile();
                    break;
                case 3:
                    ScannerInput scannerInput = new ScannerInput(filename);
                    scannerInput.readFile();
                    break;
                case 9:
                    exit = true;
                    out.print("Good bye!");
                    break;
            }
        }
    }
    
    /**
     * Display menu until a valid choice is input.
     * 
     * @return the menu choice
     */
    private static int showMenu() {
        Scanner consoleIn = new Scanner(System.in);
        boolean valid = false;
        int choice = 9;
        
        while (!valid) {
            // display menu
            out.println();
            out.println("1. Read using character-at-a-time");
            out.println("2. Read using buffered reader");
            out.println("3. Read using scanner");
            out.println("9. Exit");
            out.println();
            out.print("Option: ");
            
            // obtain user's choice
            choice = consoleIn.nextInt();
            
            // simple switch to find any valid choice
            switch (choice) {
                case 1:
                case 2:
                case 3:
                case 9:
                    valid = true;
                    break;
                default:
                    out.println();
                    out.println(String.format("Oops! '%s' is not an appropriate choice.", choice));
                    break;
            }
        }
        
        return choice;
    }
}
