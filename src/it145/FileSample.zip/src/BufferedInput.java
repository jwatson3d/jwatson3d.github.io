import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import static java.lang.System.err;
import static java.lang.System.out;

/**
 * File Input/Output using buffered i/o to
 * process a text file a line at a time.
 *
 * IT-145 Foundations of Application Development
 *
 * College of Online and Continuing Education
 * Southern New Hampshire University
 *
 * @author John Watson <john.watson@snhu.edu>
 */
public class BufferedInput {

    // represents the actual file on disk
    File file = null;

    // the filename
    String filename;

    // define array of strings to hold individual fields
    String[] fields;

    // define a format string to ensure consistent output
    // @see https://docs.oracle.com/javase/8/docs/api/java/util/Formatter.html
    String format = "%-3s %-10s %-10s %-40s";

    /**
     * Prevent default constructor being called
     */
    private BufferedInput() {

    }

    /**
     * Specialized constructor accepts a filename
     * 
     * @param filename 
     */
    BufferedInput(String filename) {
        this.filename = filename;
    }

    /**
     * Reads the selected file and prints the contents
     */
    void readFile() {

        // define a String to hold each line read from file
        String line;

        // if able to open the file
        if (prepareFile()) {

            try {

                // open the file and position to the start
                FileReader fileReader = new FileReader(file);

                // Always wrap FileReader in BufferedReader to improve throughput.
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                // now loop and print each remaining line
                while ((line = bufferedReader.readLine()) != null) {
                    fields = line.split(",");
                    out.println(String.format(format, fields[0], fields[1], fields[2], fields[3]));
                }

                // always close the file
                bufferedReader.close();

            } catch (FileNotFoundException ex) {
                err.format("FileNotFoundException: %s%n", ex);
            } catch (IOException ex) {
                err.format("IOException: %s%n", ex);
            }
        }
    }

    /**
     * Prepares a File instance using the supplied filename
     *
     * @return 'true' if the file is prepared for use
     */
    private boolean prepareFile() {

        // Determine the correct path location for the file
        // see: http://stackoverflow.com/a/10830715
        URL path = BufferedInput.class.getResource(filename);
        if (path == null) {
            err.format("File not found!! Unable to continue.\n%s", filename);
            return false;
        }

        // try to create a File instance using the calculated path
        try {
            file = new File(path.toURI());
        } catch (URISyntaxException ex) {
            err.format("IOException: %s%n", ex);
            return false;
        }

        return true;
    }
}
